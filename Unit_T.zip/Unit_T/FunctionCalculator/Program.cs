﻿using System;

namespace FunctionCalculator
{
    public class FunctionCalculator1
    {
        public double CalculateFunctionValue(double x, double N)
        {
            if (x == N)
            {
                throw new ArgumentException("Деление на 0: разрыв функции при x = N");
            }
            return 1 / (x - N);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            double N = 5; // Пример значения N
            int iterations = 20; // Пример количества итераций цикла вычислений
            double k = 10; // Пример значения k

            FunctionCalculator1 calculator = new FunctionCalculator1();

            try
            {
                for (double x = 0; x <= k; x += 0.1)
                {
                    double result = calculator.CalculateFunctionValue(x, N);
                    Console.WriteLine("f({0}) = {1}", x, result);
                }
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine("Произошло исключение: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Произошло исключение: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("Выполнение программы завершено.");
            }
        }
    }
}